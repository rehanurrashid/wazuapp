@stack('before-scripts')
<!-- Core JS files -->

<script src="{{ asset('admin/js/main/jquery.min.js') }}"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"
    integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6"
    crossorigin="anonymous"></script>
<!-- /core JS files -->


<!-- Theme JS files -->

<!-- /theme JS files -->
@stack('after-scripts')
