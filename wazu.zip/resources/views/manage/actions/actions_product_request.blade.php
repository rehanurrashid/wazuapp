<div class="btn-group" role="group" aria-label="Basic example">
    <a href="javascript:sdelete('ProductRequests/{{$product->id}}')" title="Suspend Product" class="delete-row delete-color" data-id="{{ $product->id }}"><i class="bx bx-trash 2x"  style="color:red;font-size: 1.8rem;"></i></a>
</div>
